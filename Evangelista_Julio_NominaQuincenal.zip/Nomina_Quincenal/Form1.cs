namespace Nomina_Quincenal
{
    public partial class Form1 : Form
    {
        // Constantes 
        const int Horas_Regulares = 88;
        const double Horas_Extra = 1.35;
        const double INCENTIVO = 1500;
        const double AFP = 0.0287;
        const double SFS = 0.0304;

        // Acumuladores
        int cantidad = 0;
        double totalBruto = 0;
        double totalDeducciones = 0;
        double totalNeto = 0;

        public Form1()
        {
            InitializeComponent();
        }

        // Registra un empleado en la lista y calcula los pagos
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Validar que escriba el nombre
            if (txtEmpleado.Text.Trim() == "")
            {
                MessageBox.Show("Escribe el nombre del empleado.");
                return;
            }

            // Validar que elija el contrato
            if (!rdbFijo.Checked && !rdbTemporal.Checked)
            {
                MessageBox.Show("Hay que seleccionar un tipo de contrato.");
                return;
            }

            // Validar que elija el cargo
            if (cmbCargo.SelectedIndex == -1)
            {
                MessageBox.Show("Tiene que seleccionar un cargo.");
                return;
            }

            // Validar las horas ( de 1 al 120)
            int horas;
            if (!int.TryParse(txtHoras.Text, out horas) || horas < 1 || horas > 120) 
            {
                MessageBox.Show("Las horas deben ser un número entero de 1 a 120.");
                return;
            }

            // Tarifa de los cargos
            double tarifa;
            if (cmbCargo.Text == "Auxiliar")
            {
                tarifa = 180;
            }
            else if (cmbCargo.Text == "Tecnico")
            {
                tarifa = 250;
            }
            else if (cmbCargo.Text == "Supervisor")
            {
                tarifa = 350;
            }
            else 
            {
                tarifa = 500; 
            }

            // Para saber cuántas horas son normales y cuántas son extra

            int horasNormales = horas;
            int horasExtra = 0;
            if (horas > Horas_Regulares)
            {
                horasNormales = Horas_Regulares;
                horasExtra = horas - Horas_Regulares;
            }

            // Salario regular y pago de horas extra
            double salarioRegular = horasNormales * tarifa;
            double pagoExtra = horasExtra * tarifa * Horas_Extra;

            // Incentivo de transporte
            double incentivo = 0;
            if (chkTransporte.Checked)
            {
                incentivo = INCENTIVO;
            }

            // salario Bruto
            double bruto = salarioRegular + pagoExtra + incentivo;

            // Deducciones para contrato fijo AFP y SFS

            double deducciones = 0;
            if (rdbFijo.Checked)
            {
                deducciones = (salarioRegular + pagoExtra) * (AFP + SFS);
            }

            // Neto
            double neto = bruto - deducciones;

            // Agregar a la lista
            lstNomina.Items.Add(txtEmpleado.Text.Trim() + " · " + cmbCargo.Text + " · RD$ " + neto.ToString("N2"));

            // sumar totales
            cantidad = cantidad + 1;
            totalBruto = totalBruto + bruto;
            totalDeducciones = totalDeducciones + deducciones;
            totalNeto = totalNeto + neto;
        }

        // Muestra la cantidad de empleados y los totales
        private void btnResumen_Click(object sender, EventArgs e)
        {
            if (cantidad == 0)
            {
                MessageBox.Show("Primero registra al menos un empleado.");
                return;
            }

            lblEmpleado.Text = cantidad.ToString();
            lblBruto.Text = "RD$ " + totalBruto.ToString("N2");
            lblDeducciones.Text = "RD$ " + totalDeducciones.ToString("N2");
            lblNeto.Text = "RD$ " + totalNeto.ToString("N2");
        }

        // limpiar
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtEmpleado.Clear();
            rdbFijo.Checked = true;
            cmbCargo.SelectedIndex = -1;
            txtHoras.Clear();
            chkTransporte.Checked = false;
            lstNomina.Items.Clear();
            cantidad = 0;
            totalBruto = 0;
            totalDeducciones = 0;
            totalNeto = 0;
            lblEmpleado.Text = "0";
            lblBruto.Text = "RD$ 0.00";
            lblDeducciones.Text = "RD$ 0.00";
            lblNeto.Text = "RD$ 0.00";
        }

        // Cerrar el  programa

        private void btnSalir_Click(object sender, EventArgs e)
        {
           
           this.Close();
        }
    }
}