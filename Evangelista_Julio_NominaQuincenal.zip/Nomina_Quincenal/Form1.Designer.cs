﻿namespace Nomina_Quincenal
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombre = new Label();
            lblContrato = new Label();
            lblTitulo = new Label();
            lblTitulo2 = new Label();
            lblCargo = new Label();
            lblTitulodeHoras = new Label();
            txtEmpleado = new TextBox();
            txtHoras = new TextBox();
            rdbFijo = new RadioButton();
            rdbTemporal = new RadioButton();
            cmbCargo = new ComboBox();
            chkTransporte = new CheckBox();
            btnRegistrar = new Button();
            btnResumen = new Button();
            btnLimpiar = new Button();
            lblnn = new Label();
            lstNomina = new ListBox();
            label1 = new Label();
            lblEmpleado = new Label();
            lblBruto = new Label();
            lblDeducciones = new Label();
            lblNeto = new Label();
            btnSalir = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNombre.Location = new Point(49, 84);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(70, 20);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre:";
            // 
            // lblContrato
            // 
            lblContrato.AutoSize = true;
            lblContrato.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblContrato.Location = new Point(49, 139);
            lblContrato.Name = "lblContrato";
            lblContrato.Size = new Size(73, 20);
            lblContrato.TabIndex = 1;
            lblContrato.Text = "Contrato:";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(49, 41);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(153, 19);
            lblTitulo.TabIndex = 2;
            lblTitulo.Text = "Datos del empleado";
            // 
            // lblTitulo2
            // 
            lblTitulo2.AutoSize = true;
            lblTitulo2.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo2.Location = new Point(47, 235);
            lblTitulo2.Name = "lblTitulo2";
            lblTitulo2.Size = new Size(134, 19);
            lblTitulo2.TabIndex = 3;
            lblTitulo2.Text = "Registro de pago";
            // 
            // lblCargo
            // 
            lblCargo.AutoSize = true;
            lblCargo.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCargo.Location = new Point(49, 269);
            lblCargo.Name = "lblCargo";
            lblCargo.Size = new Size(54, 20);
            lblCargo.TabIndex = 4;
            lblCargo.Text = "Cargo:";
            // 
            // lblTitulodeHoras
            // 
            lblTitulodeHoras.AutoSize = true;
            lblTitulodeHoras.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulodeHoras.Location = new Point(47, 332);
            lblTitulodeHoras.Name = "lblTitulodeHoras";
            lblTitulodeHoras.Size = new Size(232, 20);
            lblTitulodeHoras.TabIndex = 5;
            lblTitulodeHoras.Text = "Horas trabajadas en la quincena:";
            // 
            // txtEmpleado
            // 
            txtEmpleado.Location = new Point(141, 84);
            txtEmpleado.Name = "txtEmpleado";
            txtEmpleado.Size = new Size(205, 23);
            txtEmpleado.TabIndex = 6;
            // 
            // txtHoras
            // 
            txtHoras.Location = new Point(49, 360);
            txtHoras.Name = "txtHoras";
            txtHoras.Size = new Size(180, 23);
            txtHoras.TabIndex = 7;
            // 
            // rdbFijo
            // 
            rdbFijo.AutoSize = true;
            rdbFijo.Location = new Point(141, 139);
            rdbFijo.Name = "rdbFijo";
            rdbFijo.Size = new Size(51, 21);
            rdbFijo.TabIndex = 8;
            rdbFijo.TabStop = true;
            rdbFijo.Text = "Fijo";
            rdbFijo.UseVisualStyleBackColor = true;
            // 
            // rdbTemporal
            // 
            rdbTemporal.AutoSize = true;
            rdbTemporal.Location = new Point(253, 139);
            rdbTemporal.Name = "rdbTemporal";
            rdbTemporal.Size = new Size(89, 21);
            rdbTemporal.TabIndex = 9;
            rdbTemporal.TabStop = true;
            rdbTemporal.Text = "Temporal";
            rdbTemporal.UseVisualStyleBackColor = true;
            // 
            // cmbCargo
            // 
            cmbCargo.FormattingEnabled = true;
            cmbCargo.Items.AddRange(new object[] { "Auxiliar", "Tecnico", "Supervisor", "Gerente" });
            cmbCargo.Location = new Point(107, 267);
            cmbCargo.Name = "cmbCargo";
            cmbCargo.Size = new Size(239, 25);
            cmbCargo.TabIndex = 10;
            // 
            // chkTransporte
            // 
            chkTransporte.AutoSize = true;
            chkTransporte.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            chkTransporte.Location = new Point(49, 410);
            chkTransporte.Name = "chkTransporte";
            chkTransporte.Size = new Size(239, 24);
            chkTransporte.TabIndex = 11;
            chkTransporte.Text = "Recibe incentivo de transporte";
            chkTransporte.UseVisualStyleBackColor = true;
            // 
            // btnRegistrar
            // 
            btnRegistrar.BackColor = SystemColors.Highlight;
            btnRegistrar.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrar.ForeColor = SystemColors.ButtonHighlight;
            btnRegistrar.Location = new Point(47, 450);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(299, 28);
            btnRegistrar.TabIndex = 12;
            btnRegistrar.Text = "Registrar empleado";
            btnRegistrar.UseVisualStyleBackColor = false;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // btnResumen
            // 
            btnResumen.BackColor = SystemColors.Highlight;
            btnResumen.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnResumen.ForeColor = SystemColors.ButtonHighlight;
            btnResumen.Location = new Point(47, 587);
            btnResumen.Name = "btnResumen";
            btnResumen.Size = new Size(299, 28);
            btnResumen.TabIndex = 13;
            btnResumen.Text = "Mostrar Resumen";
            btnResumen.UseVisualStyleBackColor = false;
            btnResumen.Click += btnResumen_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = SystemColors.Highlight;
            btnLimpiar.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLimpiar.ForeColor = SystemColors.ButtonHighlight;
            btnLimpiar.Location = new Point(377, 587);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(299, 28);
            btnLimpiar.TabIndex = 14;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // lblnn
            // 
            lblnn.AutoSize = true;
            lblnn.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblnn.Location = new Point(602, 41);
            lblnn.Name = "lblnn";
            lblnn.Size = new Size(148, 19);
            lblnn.TabIndex = 15;
            lblnn.Text = "Nomina registrada";
            // 
            // lstNomina
            // 
            lstNomina.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstNomina.FormattingEnabled = true;
            lstNomina.Location = new Point(602, 82);
            lstNomina.Name = "lstNomina";
            lstNomina.Size = new Size(340, 213);
            lstNomina.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(602, 344);
            label1.Name = "label1";
            label1.Size = new Size(76, 19);
            label1.TabIndex = 17;
            label1.Text = "Resumen";
            // 
            // lblEmpleado
            // 
            lblEmpleado.AutoSize = true;
            lblEmpleado.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmpleado.Location = new Point(756, 383);
            lblEmpleado.Name = "lblEmpleado";
            lblEmpleado.Size = new Size(87, 20);
            lblEmpleado.TabIndex = 18;
            lblEmpleado.Text = "Empleados:";
            // 
            // lblBruto
            // 
            lblBruto.AutoSize = true;
            lblBruto.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblBruto.Location = new Point(756, 410);
            lblBruto.Name = "lblBruto";
            lblBruto.Size = new Size(51, 20);
            lblBruto.TabIndex = 19;
            lblBruto.Text = "Bruto:";
            // 
            // lblDeducciones
            // 
            lblDeducciones.AutoSize = true;
            lblDeducciones.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDeducciones.Location = new Point(756, 438);
            lblDeducciones.Name = "lblDeducciones";
            lblDeducciones.Size = new Size(100, 20);
            lblDeducciones.TabIndex = 20;
            lblDeducciones.Text = "Deducciones:";
            // 
            // lblNeto
            // 
            lblNeto.AutoSize = true;
            lblNeto.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNeto.Location = new Point(756, 469);
            lblNeto.Name = "lblNeto";
            lblNeto.Size = new Size(84, 20);
            lblNeto.TabIndex = 21;
            lblNeto.Text = "Total Neto:";
            // 
            // btnSalir
            // 
            btnSalir.BackColor = SystemColors.Highlight;
            btnSalir.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = SystemColors.ButtonHighlight;
            btnSalir.Location = new Point(710, 587);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(299, 28);
            btnSalir.TabIndex = 22;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(602, 410);
            label2.Name = "label2";
            label2.Size = new Size(51, 20);
            label2.TabIndex = 23;
            label2.Text = "Bruto:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(602, 438);
            label3.Name = "label3";
            label3.Size = new Size(100, 20);
            label3.TabIndex = 24;
            label3.Text = "Deducciones:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(602, 469);
            label4.Name = "label4";
            label4.Size = new Size(84, 20);
            label4.TabIndex = 25;
            label4.Text = "Total Neto:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(602, 383);
            label5.Name = "label5";
            label5.Size = new Size(87, 20);
            label5.TabIndex = 26;
            label5.Text = "Empleados:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1505, 748);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnSalir);
            Controls.Add(lblNeto);
            Controls.Add(lblDeducciones);
            Controls.Add(lblBruto);
            Controls.Add(lblEmpleado);
            Controls.Add(label1);
            Controls.Add(lstNomina);
            Controls.Add(lblnn);
            Controls.Add(btnLimpiar);
            Controls.Add(btnResumen);
            Controls.Add(btnRegistrar);
            Controls.Add(chkTransporte);
            Controls.Add(cmbCargo);
            Controls.Add(rdbTemporal);
            Controls.Add(rdbFijo);
            Controls.Add(txtHoras);
            Controls.Add(txtEmpleado);
            Controls.Add(lblTitulodeHoras);
            Controls.Add(lblCargo);
            Controls.Add(lblTitulo2);
            Controls.Add(lblTitulo);
            Controls.Add(lblContrato);
            Controls.Add(lblNombre);
            Font = new Font("Microsoft Sans Serif", 8.25F);
            Name = "Form1";
            Text = "Nomina Quincenal";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombre;
        private Label lblContrato;
        private Label lblTitulo;
        private Label lblTitulo2;
        private Label lblCargo;
        private Label lblTitulodeHoras;
        private TextBox txtEmpleado;
        private TextBox txtHoras;
        private RadioButton rdbFijo;
        private RadioButton rdbTemporal;
        private ComboBox cmbCargo;
        private CheckBox chkTransporte;
        private Button btnRegistrar;
        private Button btnResumen;
        private Button btnLimpiar;
        private Label lblnn;
        private ListBox lstNomina;
        private Label label1;
        private Label lblEmpleado;
        private Label lblBruto;
        private Label lblDeducciones;
        private Label lblNeto;
        private Button btnSalir;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
